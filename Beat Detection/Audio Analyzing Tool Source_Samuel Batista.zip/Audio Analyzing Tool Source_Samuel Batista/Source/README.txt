Render Scene Controls:

Note: To control the RenderableScene first you have to have focus in the OpenGL control. To do that simply click anywhere in the control. The border will change to indicate that you have control.

W � move object back (away)
S  � move object forward 
A � move object left
D � move object right
Q � rotate object
E � rotate object


For more information read the documentation included.